[ENGCARNATION.otf / donationware]

This Engcarnation font is intentionally made for fundraising to support an event with the same name.
Engcarnation, coming your way in May 2015, is a charity, arts and education event 
held by students of English Department in the University of Indonesia. 
As one of the students there, I want to support it by creating this font. 
You can help me by donating to my PayPal account: callmetwentynine@gmail.com. 
Every donation from you will be highly appreciated.

Further question or special request?
Feel free to contact me on:
email: marsnev@marsnev.com
facebook: facebook.com/marsneveneksk
twitter: twitter.com/MARSNEV

Thanks for being supportive,
MARSNEV
Jakarta, Indonesia


p.s.: don't like the uppercase "E" which looks like sigma? just ask me if you want a normal one:)