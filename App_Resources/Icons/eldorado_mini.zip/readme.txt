These icons are from Icojam (http://www.icojam.com)

Eldorado mini is a free version of Eldorado icons and includes 40x40 sized pixel-perfect PNG.
If you need vector and hi-res version of these icons you can buy them at http://www.icojam.com.

Eldorado mini free [bitmap]

Ammount of icons:
1262

Icon Sizes:
40x40

File Types:
.png: 
40x40(32bit)
